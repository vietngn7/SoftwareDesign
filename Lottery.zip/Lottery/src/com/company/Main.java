package com.company;

import java.util.Scanner;
import  model.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input number of players in the amazing show: ");
        int count = scanner.nextInt();
        try {
            AmazingShow show = new AmazingShow(count);
            show.startShow();
        }
        catch (Exception ex)
        {
            System.out.println("Error occurred: " + ex.getMessage());
        }

        scanner.close();
    }
}
