package model;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Shadow on 10/10/16.
 */
public class Loser implements Player
{
    private final static Random random = new Random();
    private Organizer organizer;
    public String name;
    private int playerID;
    private ArrayList<Integer> card;
    private int guesses;

    public Loser(int i)
    {
        playerID = i+1;
        name = "player_" + playerID;
        card = new ArrayList<>(6);
    }

    public void acceptDigit(int digit)
    {
        if(card.size()> 0 & card.contains(digit))
        {
            System.out.println(name + ": I guess " + ++guesses + " out of " + 6 + ": " + digit);
            card.remove(Integer.valueOf(digit));
        }
    }
    public void gameOver()
    {
        ((MoneyMaker)organizer).getCards(guesses, playerID-1);
    }

    public void startGame(Organizer organizer, int i)
    {
        this.organizer =  organizer;
        for(int j = 0; j < 7 ; j++)
            card.add( random.nextInt(10));
    }
}
