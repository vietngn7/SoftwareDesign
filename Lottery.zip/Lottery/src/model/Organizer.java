package model;

/**
 * Created by Shadow on 10/10/16.
 */
public interface Organizer
{
    void register(Player player);
    void unregister(Player player);
}
