package model;

/**
 * Created by Shadow on 10/10/16.
 */
public interface Player {

    void startGame(Organizer organizer, int i);

    void acceptDigit(int digit);

    void gameOver();
}
