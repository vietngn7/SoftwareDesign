package model;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Shadow on 10/10/16.
 */
public class MoneyMaker implements Organizer {

    private final Random random = new Random();
    private ArrayList<Player> players;
    private int[] playerCard;

    public MoneyMaker(int n)
    {
        players = new ArrayList<>(n);
        playerCard = new int[n];
    }

    @Override
    public void register(Player player)
    {
        players.add(player);
    }

    @Override
    public void unregister(Player player)
    {
        players.remove(player);
    }

    public void showsNumbers()
    {
        for(int i = 0; i < 6; i++)
        {
            int number = random.nextInt(10);
            for (Player player : players)
                player.acceptDigit(number);
        }
    }

    public void asktocreatecard()
    {
        for (int i = 0 ; i< players.size(); i++)
            players.get(i).startGame(this, i);
    }

    public void gameOver()
    {
        for(Player player:players)
            player.gameOver();
    }

    public void getResults()
    {
        int ind_max = getIndexMax();
        ArrayList<Player> winners = getWinners(ind_max);

        if(winners == null)
            System.out.println("There are no winners!\nYOU ARE ALL LOSERS!!");
        else
        {
            int prize = (int)(((double)playerCard[ind_max]*100)/winners.size());
            System.out.println("Winner are: ");
            System.out.println("Name\t\tPrize");
            for(Player player:winners)
            {
                String name = ((Loser)player).name;
                System.out.println(name+ "\t" + prize + "$");
            }
        }

    }

    public void getCards(int guesses, int id)
    {
        playerCard[id]= guesses;
    }

    private ArrayList<Player> getWinners(int ind_max)
    {
        if (playerCard[ind_max] == 0)
            return null;

        ArrayList<Player> winners = new ArrayList<>();
        for(int i = 0 ; i < players.size(); i++)
        {
            if(playerCard[ind_max] == playerCard[i])
                winners.add(players.get(i));
        }
        return winners;
    }
    
    private int getIndexMax()
    {
        int ind_max = 0;

        for(int i = 1; i < players.size(); i++)
        {
            if(playerCard[ind_max] < playerCard[i])
                ind_max = i;
        }
        return  ind_max;
    }
}
