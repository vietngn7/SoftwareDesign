package model;

/**
 * Created by Shadow on 10/13/16.
 */
import java.util.ArrayList;

public class AmazingShow {
    private MoneyMaker host;
    private ArrayList<Player> players = new ArrayList<>();
    public AmazingShow(int number)
    {
        if(number<=0)
            throw new IllegalArgumentException("Unacceptable number of players!");
        host = new MoneyMaker(number);
        for(int i = 0 ; i < number; i++ )
            players.add(new Loser(i));
        for(Player player : players)
            host.register(player);
    }

    public void startShow()
    {
        host.asktocreatecard();
        host.showsNumbers();
        host.gameOver();
        host.getResults();
    }
}
